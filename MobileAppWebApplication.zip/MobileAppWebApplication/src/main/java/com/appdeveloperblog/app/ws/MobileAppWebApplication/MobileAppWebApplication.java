package com.appdeveloperblog.app.ws.MobileAppWebApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileAppWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileAppWebApplication.class, args);
	}

}
